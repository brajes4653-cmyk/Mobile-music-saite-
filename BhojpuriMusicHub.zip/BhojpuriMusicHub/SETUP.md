# Bhojpuri Music Hub – setup & APK

The app stores songs in Firebase (free project): Storage = MP3 files, Firestore = song list, Auth = admin login.
You must create the Firebase project yourself (it belongs to your Google account).

## 1. Firebase project (≈10 min)
1. https://console.firebase.google.com > Add project.
2. Project settings > Add app > Android. Package name: `com.bhojpuri.musichub`. Download **google-services.json** and put it in `app/` (next to `app/build.gradle.kts`).
3. Build > Authentication > Get started > enable **Email/Password**. Users tab > Add user (your admin email + password). Copy that user's **UID**.
4. Build > Firestore Database > Create database. Rules tab > paste `firebase/firestore.rules` > Publish.
   Then Data tab > Start collection `admins` > Document ID = the UID from step 3, add any field (e.g. role = admin).
5. Build > Storage > Get started (Firebase may ask you to switch to the pay-as-you-go plan; there is a free usage allowance). Rules tab > paste `firebase/storage.rules` > Publish (accept the cross-service rules prompt).

## 2. Build the APK
**Android Studio:** File > Open `BhojpuriMusicHub` > wait for sync > Build > Build APK(s) > `app/build/outputs/apk/debug/app-debug.apk`.
**Without Android Studio:** push this folder to a GitHub repo, add secret `GOOGLE_SERVICES_JSON` (base64 of google-services.json), run the "Build APK" workflow, download the APK artifact.
Send the APK to any Android phone and install it (allow "install unknown apps").
For a signed release APK: Build > Generate Signed App Bundle / APK.

## 3. First use
Home > shield icon (top right) > sign in with the admin account > choose an audio file, enter title/singer/category, tick the permission box > Upload.
The song appears on every phone with the app. Users can stream, download for offline, favorite and make playlists (favorites/playlists/downloads are stored per phone).

Only upload music you own or have permission to distribute.
