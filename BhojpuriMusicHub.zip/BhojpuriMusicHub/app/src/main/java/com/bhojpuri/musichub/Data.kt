package com.bhojpuri.musichub

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.room.*
import kotlinx.coroutines.flow.Flow

data class Cat(val key: String, val hindi: String, val icon: ImageVector)

val CATS = listOf(
    Cat("Bhakti", "भक्ति", Icons.Rounded.SelfImprovement),
    Cat("Chhath Geet", "छठ गीत", Icons.Rounded.WbSunny),
    Cat("Holi / Fagua", "होली", Icons.Rounded.Palette),
    Cat("Vivah Geet", "विवाह गीत", Icons.Rounded.Celebration),
    Cat("Lok Geet", "लोक गीत", Icons.Rounded.Mic),
    Cat("Romantic", "रोमांटिक", Icons.Rounded.Favorite),
    Cat("Dance / DJ", "डांस", Icons.Rounded.Nightlife),
    Cat("Sad Songs", "दर्द भरे", Icons.Rounded.SentimentDissatisfied),
    Cat("Birha", "बिरहा", Icons.Rounded.Cloud),
)

/** Local row for any song the user favorites, downloads, plays or adds to a playlist. */
@Entity(tableName = "tracks")
data class Track(
    @PrimaryKey val id: String,
    val title: String,
    val singer: String,
    val category: String,
    val audioUrl: String,
    val coverUrl: String? = null,
    val durationMs: Long = 0,
    val filePath: String? = null,      // set when downloaded (app-private copy)
    val favorite: Boolean = false,
    val lastPlayed: Long = 0,
    val storagePath: String? = null
)

@Entity(tableName = "playlists")
data class Playlist(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(tableName = "playlist_tracks", primaryKeys = ["playlistId", "trackId"])
data class PlaylistTrack(val playlistId: Long, val trackId: String, val position: Long = System.nanoTime())

@Dao
interface HubDao {
    @Query("SELECT * FROM tracks") fun tracks(): Flow<List<Track>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertIfAbsent(t: Track)
    @Query("UPDATE tracks SET favorite=:f WHERE id=:id") suspend fun setFav(id: String, f: Boolean)
    @Query("UPDATE tracks SET lastPlayed=:t WHERE id=:id") suspend fun played(id: String, t: Long)
    @Query("UPDATE tracks SET filePath=:p WHERE id=:id") suspend fun setFile(id: String, p: String?)

    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE") fun playlists(): Flow<List<Playlist>>
    @Insert suspend fun insertPlaylist(p: Playlist): Long
    @Query("UPDATE playlists SET name=:n WHERE id=:id") suspend fun rename(id: Long, n: String)
    @Query("DELETE FROM playlists WHERE id=:id") suspend fun deletePlaylist(id: Long)
    @Query("DELETE FROM playlist_tracks WHERE playlistId=:id") suspend fun clearPlaylist(id: Long)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addToPlaylist(p: PlaylistTrack)
    @Query("DELETE FROM playlist_tracks WHERE playlistId=:id AND trackId=:tid") suspend fun removeFromPlaylist(id: Long, tid: String)
    @Query("SELECT * FROM playlist_tracks") fun playlistTracks(): Flow<List<PlaylistTrack>>
}

@Database(entities = [Track::class, Playlist::class, PlaylistTrack::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): HubDao
    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "hub.db").build().also { inst = it }
        }
    }
}

fun fmt(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }

fun displayName(ctx: Context, uri: Uri): String = try {
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    }
} catch (e: Exception) { null } ?: "Song"
