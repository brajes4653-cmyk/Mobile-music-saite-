package com.bhojpuri.musichub

import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Foreground media service. Media3 provides the notification (title, art, controls),
 * lock-screen controls and Bluetooth/headset button handling from the MediaSession.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs, true)       // pauses on calls / other apps (audio focus)
            .setHandleAudioBecomingNoisy(true)     // pauses when headphones disconnect
            .setWakeMode(C.WAKE_MODE_LOCAL)        // keeps playing with the screen locked
            .build()
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
