@file:OptIn(ExperimentalMaterial3Api::class)

package com.bhojpuri.musichub

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun AdminScreen(vm: MusicVM, library: List<Track>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var user by remember { mutableStateOf(Cloud.user) }
    var admin by remember { mutableStateOf<Boolean?>(null) }
    var status by remember { mutableStateOf("") }
    LaunchedEffect(user) { admin = if (user == null) false else Cloud.isAdmin() }

    Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding().imePadding()) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.adminOpen = false }) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White) }
            Text("Admin", Modifier.weight(1f), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (user != null) TextButton({ Cloud.signOut(); user = null; status = "" }) { Text("Sign out") }
        }
        if (status.isNotBlank()) Text(status, color = Magenta, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))

        when {
            user == null -> {
                var email by remember { mutableStateOf("") }
                var pass by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Sign in with the admin account created in Firebase.", color = Color.Gray)
                    OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Email") })
                    OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation())
                    GradientButton("Sign in", Icons.Rounded.Login, Modifier.fillMaxWidth()) {
                        scope.launch {
                            try { Cloud.signIn(email, pass); user = Cloud.user; status = "" }
                            catch (e: Exception) { status = "Sign-in failed: ${e.localizedMessage}" }
                        }
                    }
                }
            }
            admin == null -> Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) { CircularProgressIndicator(color = Neon) }
            admin == false -> Column(Modifier.padding(16.dp)) {
                Text("This account is not an admin, so it cannot upload songs.", color = Color.White)
                Text("Add a document with this account's UID in the Firestore 'admins' collection.", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
                Text("UID: ${user?.uid}", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
            else -> AdminContent(ctx, library, { status = it })
        }
    }
}

@Composable
private fun AdminContent(ctx: android.content.Context, library: List<Track>, setStatus: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var audio by remember { mutableStateOf<Uri?>(null) }
    var cover by remember { mutableStateOf<Uri?>(null) }
    var title by remember { mutableStateOf("") }
    var singer by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(CATS[0].key) }
    var catMenu by remember { mutableStateOf(false) }
    var owns by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(-1) }
    var toDelete by remember { mutableStateOf<Track?>(null) }
    val audioPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        audio = u; if (u != null && title.isBlank()) title = displayName(ctx, u).substringBeforeLast('.')
    }
    val coverPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { cover = it }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Upload a song", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        OutlinedButton({ audioPick.launch("audio/*") }, Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.AudioFile, null); Spacer(Modifier.width(8.dp))
            Text(audio?.let { displayName(ctx, it) } ?: "Choose MP3 / audio file", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Song title") })
        OutlinedTextField(singer, { singer = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Singer") })
        Box {
            OutlinedButton({ catMenu = true }, Modifier.fillMaxWidth()) { Text("Category: $cat"); Spacer(Modifier.weight(1f)); Icon(Icons.Rounded.ArrowDropDown, null) }
            DropdownMenu(catMenu, { catMenu = false }) {
                CATS.forEach { c -> DropdownMenuItem({ Text("${c.key}  ${c.hindi}") }, { cat = c.key; catMenu = false }) }
            }
        }
        OutlinedButton({ coverPick.launch("image/*") }, Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.Image, null); Spacer(Modifier.width(8.dp))
            Text(if (cover != null) "Cover image selected" else "Cover image (optional)")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(owns, { owns = it })
            Text("I own this music or have permission to distribute it.", color = Color.White, fontSize = 13.sp)
        }
        if (progress >= 0) LinearProgressIndicator(progress = { progress / 100f }, Modifier.fillMaxWidth(), color = Neon)
        val ready = audio != null && title.isNotBlank() && singer.isNotBlank() && owns && progress < 0
        Button({
            val a = audio ?: return@Button
            scope.launch {
                progress = 0; setStatus("Uploading…")
                try {
                    Cloud.upload(ctx, a, cover, title, singer, cat) { progress = it }
                    setStatus("Uploaded ✓  The song is now live on all devices.")
                    audio = null; cover = null; title = ""; singer = ""; owns = false
                } catch (e: Exception) { setStatus("Upload failed: ${e.localizedMessage}") }
                finally { progress = -1 }
            }
        }, Modifier.fillMaxWidth(), enabled = ready) { Icon(Icons.Rounded.CloudUpload, null); Spacer(Modifier.width(8.dp)); Text("Upload") }

        Text("Manage songs (${library.size})", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
        library.forEach { t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${t.singer} • ${t.category}", color = Color.Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton({ toDelete = t }) { Icon(Icons.Rounded.Delete, "Delete from cloud", tint = Magenta) }
            }
        }
    }
    toDelete?.let { t ->
        AlertDialog(onDismissRequest = { toDelete = null }, title = { Text("Delete song?") },
            text = { Text("“${t.title}” will be removed from the cloud for everyone.") },
            confirmButton = {
                TextButton({
                    toDelete = null
                    scope.launch { try { Cloud.delete(t); setStatus("Deleted.") } catch (e: Exception) { setStatus("Delete failed: ${e.localizedMessage}") } }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton({ toDelete = null }) { Text("Cancel") } })
    }
}
