@file:OptIn(ExperimentalMaterial3Api::class)

package com.bhojpuri.musichub

import android.Manifest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

val Neon = Color(0xFFB45CFF)
val Violet = Color(0xFF7C3AED)
val Magenta = Color(0xFFE879F9)
val CardBg = Color(0xFF17111F)
val Grad = Brush.linearGradient(listOf(Violet, Magenta))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Neon, secondary = Magenta, background = Color.Black,
                    surface = Color(0xFF120D1A), surfaceVariant = CardBg,
                    onBackground = Color.White, onSurface = Color.White
                )
            ) { AppRoot(viewModel()) }
        }
    }
}

@Composable
fun AppRoot(vm: MusicVM) {
    val library by vm.library.collectAsState()
    val local by vm.local.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
    BackHandler(vm.playerOpen || vm.adminOpen || vm.category != null || vm.openPlaylist != null) {
        when {
            vm.playerOpen -> vm.playerOpen = false
            vm.adminOpen -> vm.adminOpen = false
            vm.category != null -> vm.category = null
            else -> vm.openPlaylist = null
        }
    }
    val current = (library + local).firstOrNull { it.id == vm.currentId }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                Column {
                    if (current != null) MiniPlayer(vm, current)
                    NavigationBar(containerColor = Color(0xFF0E0A14)) {
                        listOf("Home" to Icons.Rounded.Home, "Search" to Icons.Rounded.Search,
                            "Favorites" to Icons.Rounded.Favorite, "Playlists" to Icons.Rounded.QueueMusic,
                            "Downloads" to Icons.Rounded.Download
                        ).forEachIndexed { i, (l, ic) ->
                            NavigationBarItem(selected = tab == i, onClick = { tab = i; vm.category = null; vm.openPlaylist = null },
                                icon = { Icon(ic, l) }, label = { Text(l, fontSize = 10.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, indicatorColor = Violet,
                                    unselectedIconColor = Color.Gray, unselectedTextColor = Color.Gray, selectedTextColor = Color.White))
                        }
                    }
                }
            }
        ) { pad ->
            AnimatedContent(tab, Modifier.padding(pad), transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "tab") { t ->
                if (vm.category != null && t == 0) CategoryScreen(vm, library)
                else when (t) {
                    0 -> HomeScreen(vm, library, local) { tab = 1 }
                    1 -> SearchScreen(vm, library)
                    2 -> FavoritesScreen(vm, local, library)
                    3 -> PlaylistsScreen(vm, library, local)
                    else -> DownloadsScreen(vm, local)
                }
            }
        }
        if (vm.adminOpen) AdminScreen(vm, library)
        AnimatedVisibility(vm.playerOpen, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            PlayerScreen(vm, library + local)
        }
    }
}

// ---------- shared pieces ----------
@Composable
fun Art(url: String?, mod: Modifier, radius: Dp = 14.dp) {
    Box(mod.clip(RoundedCornerShape(radius)).background(Grad), contentAlignment = Alignment.Center) {
        if (url != null) AsyncImage(model = url, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(.85f), modifier = Modifier.fillMaxSize(.5f))
    }
}

@Composable fun Empty(text: String) =
    Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) { Text(text, color = Color.Gray, textAlign = TextAlign.Center) }

@Composable fun SectionTitle(t: String) =
    Text(t, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 20.dp, 16.dp, 10.dp))

@Composable fun ScreenTitle(t: String) =
    Text(t, style = TextStyle(brush = Grad, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold), modifier = Modifier.padding(16.dp, 20.dp, 16.dp, 8.dp))

@Composable
fun GradientButton(text: String, icon: ImageVector, mod: Modifier = Modifier, onClick: () -> Unit) {
    Row(mod.clip(RoundedCornerShape(28.dp)).background(Grad).clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = Color.White); Spacer(Modifier.width(8.dp))
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SongRow(vm: MusicVM, t: Track, onClick: () -> Unit, extra: List<Pair<String, () -> Unit>> = emptyList()) {
    var menu by remember { mutableStateOf(false) }
    var pick by remember { mutableStateOf(false) }
    val active = vm.currentId == t.id
    val prog = vm.progress[t.id]
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Art(t.coverUrl, Modifier.size(52.dp), 12.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, color = if (active) Neon else Color.White)
            Text(t.singer + if (t.durationMs > 0) " • ${fmt(t.durationMs)}" else "", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray, fontSize = 13.sp)
        }
        when {
            prog != null -> Box(Modifier.size(48.dp), Alignment.Center) {
                CircularProgressIndicator(progress = { prog / 100f }, modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = Neon)
            }
            t.filePath != null -> Box(Modifier.size(48.dp), Alignment.Center) { Icon(Icons.Rounded.DownloadDone, "Downloaded", tint = Neon) }
            else -> IconButton({ vm.download(t) }) { Icon(Icons.Rounded.Download, "Download", tint = Color.Gray) }
        }
        IconButton({ vm.toggleFav(t) }) {
            Icon(if (t.favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorite", tint = if (t.favorite) Magenta else Color.Gray)
        }
        Box {
            IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "More", tint = Color.Gray) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem({ Text("Add to playlist") }, { menu = false; pick = true })
                extra.forEach { (l, a) -> DropdownMenuItem({ Text(l) }, { menu = false; a() }) }
            }
        }
    }
    if (pick) {
        val pls by vm.playlists.collectAsState()
        AlertDialog(onDismissRequest = { pick = false }, title = { Text("Add to playlist") },
            confirmButton = { TextButton({ pick = false }) { Text("Close") } },
            text = {
                if (pls.isEmpty()) Text("Create a playlist first in the Playlists tab.")
                else Column { pls.forEach { p -> TextButton({ vm.addToPlaylist(p.id, t); pick = false }) { Text(p.name) } } }
            })
    }
}

@Composable
fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, singleLine = true, label = { Text("Name") }) },
        confirmButton = { TextButton({ if (t.isNotBlank()) onOk(t.trim()) }) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

@Composable
fun TrackList(vm: MusicVM, list: List<Track>, extra: (Track) -> List<Pair<String, () -> Unit>> = { emptyList() }) {
    LazyColumn { items(list, key = { it.id }) { t -> SongRow(vm, t, { vm.play(list, list.indexOf(t)) }, extra(t)) } }
}

// ---------- screens ----------
@Composable
fun HomeScreen(vm: MusicVM, library: List<Track>, local: List<Track>, goSearch: () -> Unit) {
    val loaded = vm.remote.collectAsState().value != null
    val recent = local.filter { it.lastPlayed > 0 }.sortedByDescending { it.lastPlayed }.take(10)
    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Bhojpuri Music Hub", style = TextStyle(brush = Grad, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold))
                    Text("भोजपुरी गीत-संगीत", color = Color.Gray, fontSize = 13.sp)
                }
                IconButton({ vm.adminOpen = true }) { Icon(Icons.Rounded.AdminPanelSettings, "Admin", tint = Neon) }
            }
        }
        item {
            Row(Modifier.padding(16.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(CardBg)
                .border(1.dp, Brush.linearGradient(listOf(Violet, Magenta)), RoundedCornerShape(28.dp))
                .clickable(onClick = goSearch).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Search, null, tint = Neon); Spacer(Modifier.width(10.dp))
                Text("Search song or singer", color = Color.Gray)
            }
        }
        if (!loaded) item { Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { CircularProgressIndicator(color = Neon) } }
        item { SectionTitle("Categories") }
        items(CATS.chunked(2)) { row ->
            Row(Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { c ->
                    val n = library.count { it.category == c.key }
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(CardBg)
                        .border(1.dp, Violet.copy(.6f), RoundedCornerShape(20.dp))
                        .clickable { vm.category = c.key }.padding(16.dp)) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(Grad), Alignment.Center) { Icon(c.icon, null, tint = Color.White) }
                        Spacer(Modifier.height(10.dp))
                        Text(c.key, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${c.hindi} • $n", color = Color.Gray, fontSize = 12.sp)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (recent.isNotEmpty()) {
            item { SectionTitle("Recently played") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(recent, key = { it.id }) { t ->
                        Column(Modifier.width(130.dp).clickable { vm.play(recent, recent.indexOf(t)) }) {
                            Art(t.coverUrl, Modifier.fillMaxWidth().aspectRatio(1f), 16.dp)
                            Text(t.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                            Text(t.singer, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        item { SectionTitle("Latest songs") }
        if (loaded && library.isEmpty()) item { Empty("No songs yet. An admin can upload songs from the shield icon above.") }
        val latest = library.take(30)
        items(latest, key = { it.id }) { t -> SongRow(vm, t, { vm.play(latest, latest.indexOf(t)) }) }
    }
}

@Composable
fun CategoryScreen(vm: MusicVM, library: List<Track>) {
    val key = vm.category ?: return
    val cat = CATS.firstOrNull { it.key == key }
    val list = library.filter { it.category == key }
    Column {
        Row(Modifier.padding(8.dp, 16.dp, 8.dp, 0.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.category = null }) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White) }
            Text("$key  ${cat?.hindi ?: ""}", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        if (list.isEmpty()) Empty("No songs in this category yet.")
        else {
            GradientButton("Play all", Icons.Rounded.PlayArrow, Modifier.padding(16.dp)) { vm.play(list, 0) }
            TrackList(vm, list)
        }
    }
}

@Composable
fun SearchScreen(vm: MusicVM, library: List<Track>) {
    var q by remember { mutableStateOf("") }
    val res = if (q.isBlank()) emptyList() else library.filter { it.title.contains(q, true) || it.singer.contains(q, true) }
    Column {
        ScreenTitle("Search")
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true,
            placeholder = { Text("Song name or singer") }, leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Rounded.Close, "Clear") } },
            shape = RoundedCornerShape(28.dp))
        Spacer(Modifier.height(8.dp))
        when {
            q.isBlank() -> Empty("Type a song name or singer name.")
            res.isEmpty() -> Empty("No songs found.")
            else -> TrackList(vm, res)
        }
    }
}

@Composable
fun FavoritesScreen(vm: MusicVM, local: List<Track>, library: List<Track>) {
    val byId = library.associateBy { it.id }
    val favs = local.filter { it.favorite }.map { byId[it.id] ?: it }
    Column {
        ScreenTitle("Favorites")
        if (favs.isEmpty()) Empty("Tap the heart on any song to add it here.")
        else {
            GradientButton("Play all", Icons.Rounded.PlayArrow, Modifier.padding(16.dp, 4.dp, 16.dp, 8.dp)) { vm.play(favs, 0) }
            TrackList(vm, favs)
        }
    }
}

@Composable
fun DownloadsScreen(vm: MusicVM, local: List<Track>) {
    val list = local.filter { it.filePath != null }
    Column {
        ScreenTitle("My Downloads")
        if (list.isEmpty()) Empty("Downloaded songs appear here and play without internet.\nTap the download icon on any song.")
        else {
            GradientButton("Play all", Icons.Rounded.PlayArrow, Modifier.padding(16.dp, 4.dp, 16.dp, 8.dp)) { vm.play(list, 0) }
            TrackList(vm, list) { t -> listOf("Delete download" to { vm.removeDownload(t) }) }
        }
    }
}

@Composable
fun PlaylistsScreen(vm: MusicVM, library: List<Track>, local: List<Track>) {
    val pls by vm.playlists.collectAsState()
    val links by vm.plTracks.collectAsState()
    var creating by remember { mutableStateOf(false) }
    val open = pls.firstOrNull { it.id == vm.openPlaylist }
    if (open != null) { PlaylistDetail(vm, open, library, local, links); return }
    Column {
        ScreenTitle("Playlists")
        GradientButton("New playlist", Icons.Rounded.Add, Modifier.padding(16.dp, 4.dp, 16.dp, 8.dp)) { creating = true }
        if (pls.isEmpty()) Empty("No playlists yet.")
        else LazyColumn(contentPadding = PaddingValues(16.dp, 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(pls, key = { it.id }) { p ->
                val n = links.count { it.playlistId == p.id }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardBg)
                    .clickable { vm.openPlaylist = p.id }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Grad), Alignment.Center) { Icon(Icons.Rounded.QueueMusic, null, tint = Color.White) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(p.name, color = Color.White, fontWeight = FontWeight.SemiBold); Text("$n songs", color = Color.Gray, fontSize = 13.sp) }
                    Icon(Icons.Rounded.ChevronRight, null, tint = Color.Gray)
                }
            }
        }
    }
    if (creating) NameDialog("New playlist", "", { creating = false }) { vm.createPlaylist(it); creating = false }
}

@Composable
fun PlaylistDetail(vm: MusicVM, p: Playlist, library: List<Track>, local: List<Track>, links: List<PlaylistTrack>) {
    val byId = (local + library).associateBy { it.id }
    val list = links.filter { it.playlistId == p.id }.sortedBy { it.position }.mapNotNull { byId[it.trackId] }
    var rename by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var add by remember { mutableStateOf(false) }
    Column {
        Row(Modifier.padding(8.dp, 16.dp, 8.dp, 0.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.openPlaylist = null }) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White) }
            Text(p.name, Modifier.weight(1f), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            IconButton({ rename = true }) { Icon(Icons.Rounded.Edit, "Rename", tint = Color.White) }
            IconButton({ del = true }) { Icon(Icons.Rounded.Delete, "Delete", tint = Color.White) }
        }
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GradientButton("Play all", Icons.Rounded.PlayArrow) { if (list.isNotEmpty()) vm.play(list, 0) }
            OutlinedButton({ add = true }, Modifier.height(48.dp)) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("Add songs") }
        }
        if (list.isEmpty()) Empty("This playlist is empty.")
        else TrackList(vm, list) { t -> listOf("Remove from playlist" to { vm.removeFromPlaylist(p.id, t.id) }) }
    }
    if (rename) NameDialog("Rename playlist", p.name, { rename = false }) { vm.renamePlaylist(p.id, it); rename = false }
    if (del) AlertDialog(onDismissRequest = { del = false }, title = { Text("Delete playlist?") }, text = { Text("Your songs are not deleted.") },
        confirmButton = { TextButton({ vm.deletePlaylist(p.id); del = false; vm.openPlaylist = null }) { Text("Delete") } },
        dismissButton = { TextButton({ del = false }) { Text("Cancel") } })
    if (add) {
        val sel = remember { mutableStateListOf<Track>() }
        val candidates = library.filter { s -> list.none { it.id == s.id } }
        AlertDialog(onDismissRequest = { add = false }, title = { Text("Add songs") },
            text = {
                if (candidates.isEmpty()) Text("No more songs to add.")
                else LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(candidates, key = { it.id }) { s ->
                        Row(Modifier.fillMaxWidth().clickable { if (s in sel) sel.remove(s) else sel.add(s) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(s in sel, null); Spacer(Modifier.width(8.dp)); Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            },
            confirmButton = { TextButton({ sel.forEach { vm.addToPlaylist(p.id, it) }; add = false }) { Text("Add") } },
            dismissButton = { TextButton({ add = false }) { Text("Cancel") } })
    }
}

// ---------- player ----------
@Composable
fun MiniPlayer(vm: MusicVM, t: Track) {
    Row(Modifier.fillMaxWidth().padding(8.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF211533))
        .clickable { vm.playerOpen = true }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Art(t.coverUrl, Modifier.size(44.dp), 10.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(t.singer, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
        }
        IconButton({ vm.toggle() }) { Icon(if (vm.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", tint = Color.White) }
        IconButton({ vm.next() }) { Icon(Icons.Rounded.SkipNext, "Next", tint = Color.White) }
    }
}

@Composable
fun PlayerScreen(vm: MusicVM, all: List<Track>) {
    val t = all.firstOrNull { it.id == vm.currentId } ?: return
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(AudioManager::class.java) }
    var pos by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragVal by remember { mutableFloatStateOf(0f) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    val dur = (vm.controller?.duration?.takeIf { it > 0 } ?: t.durationMs).coerceAtLeast(1L)
    LaunchedEffect(t.id) { while (true) { if (!dragging) pos = vm.controller?.currentPosition ?: 0L; delay(300) } }

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF3B1470), Color(0xFF0E0818), Color.Black)))
        .systemBarsPadding().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.playerOpen = false }) { Icon(Icons.Rounded.KeyboardArrowDown, "Close", tint = Color.White, modifier = Modifier.size(32.dp)) }
            Text("Now playing", Modifier.weight(1f), color = Color.White, textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.weight(.5f))
        Art(t.coverUrl, Modifier.fillMaxWidth().aspectRatio(1f), 28.dp)
        Spacer(Modifier.weight(.5f))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.singer, color = Color.Gray, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val prog = vm.progress[t.id]
            when {
                prog != null -> CircularProgressIndicator(progress = { prog / 100f }, modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = Neon)
                t.filePath != null -> Icon(Icons.Rounded.DownloadDone, "Downloaded", tint = Neon)
                else -> IconButton({ vm.download(t) }) { Icon(Icons.Rounded.Download, "Download", tint = Color.White) }
            }
            IconButton({ vm.toggleFav(t) }) {
                Icon(if (t.favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorite", tint = if (t.favorite) Magenta else Color.White, modifier = Modifier.size(30.dp))
            }
        }
        Slider(if (dragging) dragVal else pos.toFloat().coerceIn(0f, dur.toFloat()), { dragging = true; dragVal = it },
            valueRange = 0f..dur.toFloat(),
            onValueChangeFinished = { vm.seek(dragVal.toLong()); pos = dragVal.toLong(); dragging = false },
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Neon, inactiveTrackColor = Color.White.copy(.2f)))
        Row(Modifier.fillMaxWidth()) {
            Text(fmt(if (dragging) dragVal.toLong() else pos), color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.weight(1f)); Text(fmt(dur), color = Color.Gray, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.toggleShuffle() }) { Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (vm.shuffle) Neon else Color.Gray) }
            IconButton({ vm.prev() }) { Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(40.dp)) }
            Box(Modifier.size(72.dp).clip(CircleShape).background(Grad).clickable { vm.toggle() }, Alignment.Center) {
                Icon(if (vm.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", tint = Color.White, modifier = Modifier.size(40.dp))
            }
            IconButton({ vm.next() }) { Icon(Icons.Rounded.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(40.dp)) }
            IconButton({ vm.cycleRepeat() }) {
                Icon(if (vm.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, "Repeat",
                    tint = if (vm.repeat == Player.REPEAT_MODE_OFF) Color.Gray else Neon)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.VolumeUp, "Volume", tint = Color.Gray)
            Slider(vol, { vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0) },
                valueRange = 0f..am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat(),
                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Magenta, inactiveTrackColor = Color.White.copy(.2f)))
        }
        Spacer(Modifier.height(16.dp))
    }
}
