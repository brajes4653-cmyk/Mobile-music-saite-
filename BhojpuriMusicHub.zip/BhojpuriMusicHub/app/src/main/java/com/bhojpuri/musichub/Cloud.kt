package com.bhojpuri.musichub

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.UUID

/** All cloud access: Firebase Auth (admin login), Firestore (song database), Storage (MP3 files). */
object Cloud {
    private val db get() = FirebaseFirestore.getInstance()
    private val auth get() = FirebaseAuth.getInstance()
    private val storage get() = FirebaseStorage.getInstance()

    val user get() = auth.currentUser

    suspend fun signIn(email: String, password: String) { auth.signInWithEmailAndPassword(email.trim(), password).await() }
    fun signOut() = auth.signOut()

    suspend fun isAdmin(): Boolean {
        val u = auth.currentUser ?: return false
        return try { db.collection("admins").document(u.uid).get().await().exists() } catch (e: Exception) { false }
    }

    /** Live list of all songs. Firestore caches it on the device, so the list also shows offline. */
    fun songs(onError: (String) -> Unit): Flow<List<Track>> = callbackFlow {
        val reg = db.collection("songs").orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) { onError(err.localizedMessage ?: "unknown"); trySend(emptyList()); return@addSnapshotListener }
                trySend(snap?.documents?.mapNotNull { d ->
                    val url = d.getString("audioUrl") ?: return@mapNotNull null
                    Track(
                        id = d.id, title = d.getString("title") ?: "Untitled", singer = d.getString("singer") ?: "Unknown",
                        category = d.getString("category") ?: "Other", audioUrl = url, coverUrl = d.getString("coverUrl"),
                        durationMs = d.getLong("durationMs") ?: 0L, storagePath = d.getString("storagePath")
                    )
                } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    suspend fun upload(ctx: Context, audio: Uri, cover: Uri?, title: String, singer: String, category: String, onProgress: (Int) -> Unit) {
        val uid = auth.currentUser?.uid ?: error("Sign in first")
        val id = UUID.randomUUID().toString()
        val dur = withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try { r.setDataSource(ctx, audio); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L }
            catch (e: Exception) { 0L } finally { try { r.release() } catch (_: Exception) {} }
        }
        val aRef = storage.reference.child("songs/$id")
        val aType = ctx.contentResolver.getType(audio)?.takeIf { it.startsWith("audio/") } ?: "audio/mpeg"
        aRef.putFile(audio, StorageMetadata.Builder().setContentType(aType).build())
            .addOnProgressListener { onProgress((100 * it.bytesTransferred / it.totalByteCount.coerceAtLeast(1)).toInt()) }
            .await()
        val aUrl = aRef.downloadUrl.await().toString()
        var cUrl: String? = null
        if (cover != null) {
            val cRef = storage.reference.child("covers/$id")
            val cType = ctx.contentResolver.getType(cover)?.takeIf { it.startsWith("image/") } ?: "image/jpeg"
            cRef.putFile(cover, StorageMetadata.Builder().setContentType(cType).build()).await()
            cUrl = cRef.downloadUrl.await().toString()
        }
        db.collection("songs").document(id).set(
            hashMapOf(
                "title" to title.trim(), "singer" to singer.trim(), "category" to category,
                "audioUrl" to aUrl, "coverUrl" to cUrl, "storagePath" to "songs/$id",
                "durationMs" to dur, "uploadedBy" to uid, "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun delete(t: Track) {
        db.collection("songs").document(t.id).delete().await()
        try { storage.reference.child("songs/${t.id}").delete().await() } catch (_: Exception) {}
        try { storage.reference.child("covers/${t.id}").delete().await() } catch (_: Exception) {}
    }
}
