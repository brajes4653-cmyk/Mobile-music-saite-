package com.bhojpuri.musichub

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private fun Track.toItem(): MediaItem {
    val f = filePath?.let { File(it) }?.takeIf { it.exists() }   // downloaded copy plays offline
    val src = f?.let { Uri.fromFile(it).toString() } ?: audioUrl
    return MediaItem.Builder().setMediaId(id).setUri(src)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(title).setArtist(singer).setAlbumTitle(category)
                .setArtworkUri(coverUrl?.let { Uri.parse(it) }).build()
        ).build()
}

class MusicVM(app: Application) : AndroidViewModel(app) {
    private val dao = Db.get(app).dao()
    var message by mutableStateOf<String?>(null)

    /** null = first cloud snapshot not received yet */
    val remote: StateFlow<List<Track>?> = Cloud.songs { message = "Cloud error: $it" }
        .map<List<Track>, List<Track>?> { it }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val local = dao.tracks().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val library: StateFlow<List<Track>> = combine(remote, local) { r, l ->
        val m = l.associateBy { it.id }
        (r ?: emptyList()).map { t -> m[t.id]?.let { t.copy(filePath = it.filePath, favorite = it.favorite, lastPlayed = it.lastPlayed) } ?: t }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val playlists = dao.playlists().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val plTracks = dao.playlistTracks().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    var controller: MediaController? = null
    var playing by mutableStateOf(false)
    var currentId by mutableStateOf<String?>(null)
    var shuffle by mutableStateOf(false)
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    var playerOpen by mutableStateOf(false)
    var adminOpen by mutableStateOf(false)
    var category by mutableStateOf<String?>(null)
    var openPlaylist by mutableStateOf<Long?>(null)
    val progress = mutableStateMapOf<String, Int>()

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
            currentId = item?.mediaId?.takeIf { it.isNotEmpty() }
            val id = currentId ?: return
            (library.value + local.value).firstOrNull { it.id == id }?.let { t ->
                viewModelScope.launch { dao.insertIfAbsent(t); dao.played(id, System.currentTimeMillis()) }
            }
        }
        override fun onShuffleModeEnabledChanged(e: Boolean) { shuffle = e }
        override fun onRepeatModeChanged(m: Int) { repeat = m }
        override fun onPlayerError(error: PlaybackException) {
            message = "Can't play this song. Check your internet or download it first."
        }
    }

    init {
        val ctx = getApplication<Application>()
        val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        f.addListener({
            val c = f.get(); controller = c; c.addListener(listener)
            playing = c.isPlaying; shuffle = c.shuffleModeEnabled; repeat = c.repeatMode
            currentId = c.currentMediaItem?.mediaId?.takeIf { it.isNotEmpty() }
        }, ContextCompat.getMainExecutor(ctx))
    }

    // ---- playback ----
    fun play(list: List<Track>, index: Int) {
        val c = controller ?: run { message = "Player is starting, try again"; return }
        if (list.isEmpty()) return
        c.setMediaItems(list.map { it.toItem() }, index.coerceIn(0, list.lastIndex), 0L)
        c.prepare(); c.play()
    }
    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNext() }
    fun prev() { controller?.let { if (it.currentPosition > 3000 || !it.hasPreviousMediaItem()) it.seekTo(0) else it.seekToPrevious() } }
    fun seek(ms: Long) { controller?.seekTo(ms) }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    // ---- favorites / downloads ----
    private suspend fun ensure(t: Track) = dao.insertIfAbsent(t.copy(filePath = null, favorite = false))
    fun toggleFav(t: Track) = viewModelScope.launch { ensure(t); dao.setFav(t.id, !t.favorite) }

    fun download(t: Track) {
        if (progress.containsKey(t.id) || t.filePath != null) return
        val dir = File(getApplication<Application>().filesDir, "downloads").apply { mkdirs() }
        val out = File(dir, "${t.id}.mp3")
        viewModelScope.launch {
            progress[t.id] = 0
            try {
                ensure(t)
                withContext(Dispatchers.IO) {
                    val conn = URL(t.audioUrl).openConnection() as HttpURLConnection
                    conn.connectTimeout = 15000; conn.readTimeout = 30000; conn.connect()
                    if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
                    val len = conn.contentLengthLong
                    conn.inputStream.use { i ->
                        out.outputStream().use { o ->
                            val buf = ByteArray(32 * 1024); var n: Int; var tot = 0L; var last = -1
                            while (i.read(buf).also { n = it } != -1) {
                                o.write(buf, 0, n); tot += n
                                if (len > 0) { val p = (tot * 100 / len).toInt(); if (p != last) { last = p; progress[t.id] = p } }
                            }
                        }
                    }
                }
                dao.setFile(t.id, out.absolutePath)
                message = "Downloaded: ${t.title}"
            } catch (e: Exception) {
                out.delete(); message = "Download failed. Check your internet."
            } finally { progress.remove(t.id) }
        }
    }

    /** Deletes only this app's downloaded copy. */
    fun removeDownload(t: Track) = viewModelScope.launch {
        t.filePath?.let { File(it).delete() }; dao.setFile(t.id, null)
    }

    // ---- playlists ----
    fun createPlaylist(n: String) = viewModelScope.launch { dao.insertPlaylist(Playlist(name = n)) }
    fun renamePlaylist(id: Long, n: String) = viewModelScope.launch { dao.rename(id, n) }
    fun deletePlaylist(id: Long) = viewModelScope.launch { dao.clearPlaylist(id); dao.deletePlaylist(id) }
    fun addToPlaylist(id: Long, t: Track) = viewModelScope.launch { ensure(t); dao.addToPlaylist(PlaylistTrack(id, t.id)) }
    fun removeFromPlaylist(id: Long, tid: String) = viewModelScope.launch { dao.removeFromPlaylist(id, tid) }

    override fun onCleared() { controller?.removeListener(listener); controller?.release() }
}
